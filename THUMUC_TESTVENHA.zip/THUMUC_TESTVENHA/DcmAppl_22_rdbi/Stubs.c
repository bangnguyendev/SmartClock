/*****************************************************************************/
/*                       Stub source for test project                        */
/*****************************************************************************/
/*
 *    Filename:       stub.h
 *    Author:         rkh1hc
 *    Generated on:   05-Jan-2017
 */
 /*****************************************************************************/


#include "stubs.h"

Std_ReturnType Dem_GetEventFailed (Dem_EventIdType EventId, Dem_EventStatusType *EventStatus_p)
{


}
FUNC( uint16, PDUR_CODE ) PduR_GetConfigurationId()
{

}
Std_ReturnType BOUND(value_min, value, value_max)
{

}
uint16 RBWauVolt_getKL15Voltage()

{

}
uint16 RBLiPS_GetSupplyVoltage_u16()
{

}





