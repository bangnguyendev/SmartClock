/*
 * RBDHP_DiagnosisProtectionState.h
 *
 *  Created on: Mar 9, 2017
 *      Author: rkh1hc
 */

#ifndef HDR_EMPTY_RBDHP_DIAGNOSISPROTECTIONSTATE_H_
#define HDR_EMPTY_RBDHP_DIAGNOSISPROTECTIONSTATE_H_



#endif /* HDR_EMPTY_RBDHP_DIAGNOSISPROTECTIONSTATE_H_ */
