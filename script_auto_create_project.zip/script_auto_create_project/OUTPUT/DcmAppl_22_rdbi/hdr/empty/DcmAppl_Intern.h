/*
 * DcmAppl_Intern.h
 *
 *  Created on: Apr 22, 2020
 *      Author: nbg7hc
 */

#ifndef HDR_DCMAPPL_INTERN_H_
#define HDR_DCMAPPL_INTERN_H_


#include "include.h"

#endif /* HDR_DCMAPPL_INTERN_H_ */
