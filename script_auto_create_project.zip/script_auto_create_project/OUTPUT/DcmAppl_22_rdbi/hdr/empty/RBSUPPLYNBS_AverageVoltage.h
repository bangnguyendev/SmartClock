/*
 * RBSUPPLYNBS_AverageVoltage.h
 *
 *  Created on: Apr 22, 2020
 *      Author: nbg7hc
 */

#ifndef HDR_RBSUPPLYNBS_AVERAGEVOLTAGE_H_
#define HDR_RBSUPPLYNBS_AVERAGEVOLTAGE_H_


#include "include.h"

#endif /* HDR_RBSUPPLYNBS_AVERAGEVOLTAGE_H_ */
